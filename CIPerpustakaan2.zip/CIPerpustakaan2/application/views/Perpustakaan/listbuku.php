<html>
<head>
<title>My Form</title>
</head>
<body bgcolor='lightgreen'>

<?php
	echo $tabel;
?>

<p><?php echo anchor('buku/inputbuku', 'Input Data'); ?></p> <!--anchor = link method-->

</body>
</html>